package com.example.demo.pckg1;

import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
@Repository
public class DataB {

    ArrayList<Kid> kids;
    ArrayList<Course> courses  = new ArrayList<>();
    ;
    ArrayList<Leader> leaders;
    ArrayList<Parent> parents;
    ArrayList<Category> categories;

    public DataB(){
        kids = new ArrayList<>();
        courses = new ArrayList<>();
        leaders = new ArrayList<>();
        parents = new ArrayList<>();
    }



    public ArrayList<Course> addCourses() throws ParseException {
        String sDate1="21/08/2021";
        String sDate2="1/02/2021";
        String sDate3="1/08/2021";
        String sDate4="1/08/2020";
        String sDate5="1/07/2021";
        String sDate6="23/08/2021";
        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
        Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
        Date date3=new SimpleDateFormat("dd/MM/yyyy").parse(sDate3);
        Date date4=new SimpleDateFormat("dd/MM/yyyy").parse(sDate4);
        Date date5=new SimpleDateFormat("dd/MM/yyyy").parse(sDate5);
        Date date6=new SimpleDateFormat("dd/MM/yyyy").parse(sDate6);
        Date[] dates={date1,date2,date3,date4,date5,date6};
String cor="course";
for ( int i=0; i<41;i++){
    int j = (int)(Math.random() * 6);
    courses.add(new Course(i+"","course"+j,  dates[j],dates[j] , Day.Friday , ""));
}
return  courses;
    }
    private void AddCategories(){

        Category category1 = new Category("category1","1001","1");
        categories.add(category1);
        Category category2 = new Category("category2","2002","2");
        categories.add(category2);
        Category category3 = new Category("category3","3003","3");
        categories.add(category3);
        Category category4 = new Category("category4","4004","4");
        categories.add(category4);
        Category category5 = new Category("category5","5005","5");
        categories.add(category5);

    }
    public  ArrayList<Parent> AddParents() throws ParseException {
        String[] Firstnames ={ "Aaron",
                "Daanyaal", "Jonny", "Ruaidhri",
                "Valery",
                "Shaun-Paul"};
        String[] Lastnames ={ "Ronan-Benedict",
                "Shadow",
                "Usman",  "Owen",
                "Pablo","Pardeepraj"};
        String[] gmail ={ "Aaron@gmail.com",
                "Shadow@gmail.com",
                "Usman@gmail.com",  "Owen@gmail.com",
                "Pablo@gmail.com","Pardeepraj@gmail.com"};
        String[] pass ={ "Aaron12!",
                "Shadow14!",
                "Usman15!",  "Owen@17!",
                "Pablo18!","Pardee19!"};
        String sDate1="21/08/2021";
        String sDate2="1/02/2021";
        String sDate3="1/08/2021";
        String sDate4="1/08/2020";
        String sDate5="1/07/2021";
        String sDate6="23/08/2021";
        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
        Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
        Date date3=new SimpleDateFormat("dd/MM/yyyy").parse(sDate3);
        Date date4=new SimpleDateFormat("dd/MM/yyyy").parse(sDate4);
        Date date5=new SimpleDateFormat("dd/MM/yyyy").parse(sDate5);
        Date date6=new SimpleDateFormat("dd/MM/yyyy").parse(sDate6);
        Date[] date={date1,date2,date3,date4,date5,date6};
        for (int i=0;i<100;i++){
            int j = (int)(Math.random() * 6);
            Parent p = new Parent(Firstnames[j],Lastnames[j],gmail[j],pass[j]);
            p.setActiveDate(date[j]);
            parents.add(p);
        }
        return parents;
    }
    public  ArrayList<Kid> AddKids() throws ParseException {
             addCourses();
        String[] Firstnames ={ "Aaron",
                "Daanyaal", "Jonny", "Ruaidhri",
                "Valery",
                "Shaun-Paul"};
        String[] Lastnames ={ "Ronan-Benedict",
                "Shadow",
                "Usman",  "Owen",
                "Pablo","Pardeepraj"};
        String[] gmail ={ "Aaron@gmail.com",
                "Shadow@gmail.com",
                "Usman@gmail.com",  "Owen@gmail.com",
                "Pablo@gmail.com","Pardeepraj@gmail.com"};
        String[] pass ={ "Aaron12!",
                "Shadow14!",
                "Usman15!",  "Owen@17!",
                "Pablo18!","Pardee19!"};
        String sDate1="21/08/2021";
        String sDate2="1/02/2021";
        String sDate3="1/08/2021";
        String sDate4="1/08/2020";
        String sDate5="1/07/2021";
        String sDate6="23/08/2021";
        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
        Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
        Date date3=new SimpleDateFormat("dd/MM/yyyy").parse(sDate3);
        Date date4=new SimpleDateFormat("dd/MM/yyyy").parse(sDate4);
        Date date5=new SimpleDateFormat("dd/MM/yyyy").parse(sDate5);
        Date date6=new SimpleDateFormat("dd/MM/yyyy").parse(sDate6);
        Date[] date={date1,date2,date3,date4,date5,date6};
        for (int i=0;i<100;i++){
            int j = (int)(Math.random() * 6);
            int f = (int)(Math.random() * 39);

            Kid k = new Kid(i+"",Firstnames[j],date1,Gender.Female,"1");
            k.setActiveDate(date[j]);
           k.setActiveCourses( k.addCourse(courses.get(f).getID()));
            courses.get(f).AddKids(k.getId());
            kids.add(k);

        }
        return kids;
    }

}
