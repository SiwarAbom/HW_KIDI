package com.example.demo.pckg1;

public enum Status {
Active, InActive, Pending
}
