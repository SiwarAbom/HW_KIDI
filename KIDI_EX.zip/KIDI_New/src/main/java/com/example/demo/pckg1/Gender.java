package com.example.demo.pckg1;

public enum Gender {
Male,Female,NotRelevant
}
