package com.example.demo.pckg1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KidiApplicationTests {

	@Test
	void contextLoads() {
	}

}
